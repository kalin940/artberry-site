﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.Managers.SessionManager
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.StorageEntities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ArtberryFunctions.Managers
{
  public class SessionManager
  {
    public CloudTable SessionsTable { get; set; }

    public SessionManager() => this.SessionsTable = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureWebJobsStorage")).CreateCloudTableClient().GetTableReference("Sessions");

    public SessionManager(CloudTable table) => this.SessionsTable = table;

    public async Task<IEnumerable<Session>> GetUserSessions(string userId)
    {
      TableQuerySegment<Session> source = await this.SessionsTable.ExecuteQuerySegmentedAsync<Session>(new TableQuery<Session>().Where(TableQuery.GenerateFilterCondition("UserId", "eq", userId)), new TableContinuationToken());
      return (source != null ? (IEnumerable<Session>) source.ToArray<Session>() : (IEnumerable<Session>) (Session[]) null) ?? Enumerable.Empty<Session>();
    }

    public async Task<bool> IsAdminSession(string sessionId)
    {
      TableQuerySegment<Session> source = await this.SessionsTable.ExecuteQuerySegmentedAsync<Session>(new TableQuery<Session>().Where(TableQuery.GenerateFilterCondition("Id", "eq", sessionId)), new TableContinuationToken());
      return (source != null ? source.FirstOrDefault<Session>() : (Session) null) != null && source.FirstOrDefault<Session>().IsAdmin;
    }

    public async Task<bool> DeleteSession(string sessionId)
    {
      TableQuerySegment<Session> source = await this.SessionsTable.ExecuteQuerySegmentedAsync<Session>(new TableQuery<Session>().Where(TableQuery.GenerateFilterCondition("Id", "eq", sessionId)), new TableContinuationToken());
      if ((source != null ? source.FirstOrDefault<Session>() : (Session) null) == null)
        return false;
      TableResult tableResult = await this.SessionsTable.ExecuteAsync(TableOperation.Delete((ITableEntity) source.FirstOrDefault<Session>()));
      return true;
    }

    public async Task<bool> ValidateSession(string sessionId)
    {
      TableQuerySegment<Session> result = await this.SessionsTable.ExecuteQuerySegmentedAsync<Session>(new TableQuery<Session>().Where(TableQuery.GenerateFilterCondition("Id", "eq", sessionId)), new TableContinuationToken());
      TableQuerySegment<Session> source1 = result;
      if ((source1 != null ? source1.FirstOrDefault<Session>() : (Session) null) == null)
        return false;
      string str = Guid.NewGuid().ToString();
      EventLog eventLog = new EventLog();
      eventLog.UserId = result.FirstOrDefault<Session>().UserId;
      eventLog.Description = "Check Session";
      eventLog.EventId = 2;
      eventLog.PartitionKey = str;
      eventLog.RowKey = str;
      await new EventLogManager().AddEventLog(eventLog);
      TableQuerySegment<Session> source2 = result;
      DateTime? nullable = source2 != null ? new DateTime?(source2.FirstOrDefault<Session>().DateEnd) : new DateTime?();
      DateTime utcNow = DateTime.UtcNow;
      return nullable.HasValue && nullable.GetValueOrDefault() > utcNow;
    }

    public async Task<string> ValidateSessionReturnUserId(string sessionId)
    {
      TableQuerySegment<Session> source = await this.SessionsTable.ExecuteQuerySegmentedAsync<Session>(new TableQuery<Session>().Where(TableQuery.GenerateFilterCondition("Id", "eq", sessionId)), new TableContinuationToken());
      return (source != null ? source.FirstOrDefault<Session>() : (Session) null) != null ? (source != null ? source.FirstOrDefault<Session>().UserId : (string) null) : string.Empty;
    }
  }
}
