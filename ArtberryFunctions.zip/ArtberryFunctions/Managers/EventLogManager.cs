﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.Managers.EventLogManager
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.StorageEntities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ArtberryFunctions.Managers
{
  public class EventLogManager
  {
    public CloudTable EventsTable { get; set; }

    public EventLogManager() => this.EventsTable = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureWebJobsStorage")).CreateCloudTableClient().GetTableReference("EventLogs");

    public async Task<IEnumerable<EventLog>> GetEvents(string userId)
    {
      TableQuerySegment<EventLog> source = await this.EventsTable.ExecuteQuerySegmentedAsync<EventLog>(new TableQuery<EventLog>().Where(TableQuery.GenerateFilterCondition("UserId", "eq", userId)), new TableContinuationToken());
      return (source != null ? (IEnumerable<EventLog>) source.ToArray<EventLog>() : (IEnumerable<EventLog>) (EventLog[]) null) ?? Enumerable.Empty<EventLog>();
    }

    public async Task AddEventLog(EventLog eventLog)
    {
      TableResult tableResult = await this.EventsTable.ExecuteAsync(TableOperation.Insert((ITableEntity) eventLog));
    }

    public async Task ClearEventLogs()
    {
      TableQuerySegment<EventLog> tableQuerySegment = await this.EventsTable.ExecuteQuerySegmentedAsync<EventLog>(new TableQuery<EventLog>().Where(TableQuery.GenerateFilterConditionForDate("Timestamp", "lt", (DateTimeOffset) DateTime.UtcNow.AddDays(-3.0))), new TableContinuationToken());
      Dictionary<string, TableBatchOperation> batches = new Dictionary<string, TableBatchOperation>();
      foreach (EventLog entity in tableQuerySegment)
      {
        TableBatchOperation batch = (TableBatchOperation) null;
        if (!batches.TryGetValue(entity.PartitionKey, out batch))
          batches[entity.PartitionKey] = batch = new TableBatchOperation();
        batch.Add(TableOperation.Delete((ITableEntity) entity));
        if (batch.Count == 100)
        {
          IList<TableResult> tableResultList = await this.EventsTable.ExecuteBatchAsync(batch);
          batches[entity.PartitionKey] = new TableBatchOperation();
        }
      }
      foreach (TableBatchOperation batch in batches.Values)
      {
        if (batch.Count > 0)
        {
          IList<TableResult> tableResultList = await this.EventsTable.ExecuteBatchAsync(batch);
        }
      }
      batches = (Dictionary<string, TableBatchOperation>) null;
    }
  }
}
