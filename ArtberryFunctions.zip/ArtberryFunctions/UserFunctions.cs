﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.UserFunctions
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.Helpers;
using ArtberryFunctions.Managers;
using ArtberryFunctions.StorageEntities;
using ArtberryFunctions.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using SendGrid.Helpers.Mail;
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace ArtberryFunctions
{
  public class UserFunctions
  {
    [FunctionName("GetUserInfo")]
    [OpenApiOperation("user-info/{id}", new string[] {"user-info"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiParameter("id", In = ParameterLocation.Query, Required = true, Type = typeof (string), Description = "My user id")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (UserViewModel), Description = "User info")]
    public static async Task<IActionResult> GetUser([HttpTrigger] HttpRequest req, ILogger log, string id)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        if (string.IsNullOrEmpty(sessionId))
          return (IActionResult) new UnauthorizedResult();
        if (!await new SessionManager().ValidateSession(sessionId))
          return (IActionResult) new UnauthorizedResult();
        User user = await new UsersManager().GetUser(id);
        if (user == null)
          return (IActionResult) new NotFoundObjectResult((object) id);
        UserViewModel viewModel = new UserViewModel();
        viewModel.User = user;
        SubscriptionManager subscriptionManager1 = new SubscriptionManager();
        int? subscriptionId = user.SubscriptionId;
        if (subscriptionId.HasValue)
        {
          UserViewModel userViewModel = viewModel;
          SubscriptionManager subscriptionManager2 = subscriptionManager1;
          subscriptionId = user.SubscriptionId;
          int subId = subscriptionId.Value;
          userViewModel.Subscription = await subscriptionManager2.GetSubscription(subId);
          userViewModel = (UserViewModel) null;
        }
        return (IActionResult) new OkObjectResult((object) viewModel);
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 1);
        interpolatedStringHandler.AppendLiteral("Exception - GetUserInfo: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "GetUserInfo error");
      }
    }

    [FunctionName("GetUserBySession")]
    [OpenApiOperation("session-user", new string[] {"session-user"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (UserViewModel), Description = "User info")]
    public static async Task<IActionResult> GetUserBySession([HttpTrigger] HttpRequest req, ILogger log)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        if (string.IsNullOrEmpty(sessionId))
          return (IActionResult) new UnauthorizedResult();
        string id = await new SessionManager().ValidateSessionReturnUserId(sessionId);
        if (string.IsNullOrEmpty(id))
          return (IActionResult) new UnauthorizedResult();
        User user = await new UsersManager().GetUser(id);
        if (user == null)
          return (IActionResult) new NotFoundObjectResult((object) id);
        UserViewModel viewModel = new UserViewModel();
        viewModel.User = user;
        SubscriptionManager subscriptionManager1 = new SubscriptionManager();
        int? subscriptionId = user.SubscriptionId;
        if (subscriptionId.HasValue)
        {
          UserViewModel userViewModel = viewModel;
          SubscriptionManager subscriptionManager2 = subscriptionManager1;
          subscriptionId = user.SubscriptionId;
          int subId = subscriptionId.Value;
          userViewModel.Subscription = await subscriptionManager2.GetSubscription(subId);
          userViewModel = (UserViewModel) null;
        }
        return (IActionResult) new OkObjectResult((object) viewModel);
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 1);
        interpolatedStringHandler.AppendLiteral("Exception - GetUserInfo: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "GetUserInfo error");
      }
    }

    [FunctionName("ChangeEmail")]
    [OpenApiOperation("change-email", new string[] {"change-email"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiRequestBody("application/json", typeof (UpdateUserEmailViewModel), Description = "New email and user id", Required = true)]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> ChangeEmail([HttpTrigger] HttpRequest req, ILogger log)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        if (string.IsNullOrEmpty(sessionId))
          return (IActionResult) new UnauthorizedResult();
        if (!await new SessionManager().ValidateSession(sessionId))
          return (IActionResult) new UnauthorizedResult();
        HttpResponseBody<UpdateUserEmailViewModel> bodyAsync = await req.GetBodyAsync<UpdateUserEmailViewModel>();
        if (!bodyAsync.IsValid)
          return (IActionResult) new BadRequestObjectResult((object) ("Model is invalid: " + string.Join(", ", bodyAsync.ValidationResults.Select<ValidationResult, string>((Func<ValidationResult, string>) (s => s.ErrorMessage)).ToArray<string>())));
        UpdateUserEmailViewModel updateView = bodyAsync.Value;
        UsersManager userManager = new UsersManager();
        User user = await userManager.GetUser(updateView.Id);
        if (user == null)
          return (IActionResult) new NotFoundObjectResult((object) updateView.Id);
        if (await userManager.GetUserByEmail(updateView.Email) != null)
          return (IActionResult) new BadRequestObjectResult((object) "Email exists");
        user.Email = updateView.Email;
        await userManager.UpdateUser(user);
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(34, 3);
        interpolatedStringHandler.AppendLiteral("ChangeEmail - User ");
        interpolatedStringHandler.AppendFormatted(user.Name);
        interpolatedStringHandler.AppendLiteral(", ");
        interpolatedStringHandler.AppendFormatted(user.Id);
        interpolatedStringHandler.AppendLiteral(", new Email: ");
        interpolatedStringHandler.AppendFormatted(updateView.Email);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogInformation(stringAndClear, objArray);
        return (IActionResult) new OkObjectResult((object) true);
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 1);
        interpolatedStringHandler.AppendLiteral("Exception - ChangeEmail: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "ChangeEmail error");
      }
    }

    [FunctionName("ChangePassword")]
    [OpenApiOperation("change-password", new string[] {"change-password"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiRequestBody("application/json", typeof (UpdateUserPasswordViewModel), Description = "New and old Password, User id", Required = true)]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> ChangePassword([HttpTrigger] HttpRequest req, ILogger log)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        if (string.IsNullOrEmpty(sessionId))
          return (IActionResult) new UnauthorizedResult();
        if (!await new SessionManager().ValidateSession(sessionId))
          return (IActionResult) new UnauthorizedResult();
        HttpResponseBody<UpdateUserPasswordViewModel> bodyAsync = await req.GetBodyAsync<UpdateUserPasswordViewModel>();
        if (!bodyAsync.IsValid)
          return (IActionResult) new BadRequestObjectResult((object) ("Model is invalid: " + string.Join(", ", bodyAsync.ValidationResults.Select<ValidationResult, string>((Func<ValidationResult, string>) (s => s.ErrorMessage)).ToArray<string>())));
        UpdateUserPasswordViewModel updateView = bodyAsync.Value;
        UsersManager userManager = new UsersManager();
        User user = await userManager.GetUser(updateView.Id);
        if (user == null)
          return (IActionResult) new NotFoundObjectResult((object) updateView.Id);
        if (!PasswordHasher.VerifyHashedPassword(user.Password, updateView.Password))
          return (IActionResult) new NotFoundObjectResult((object) updateView.Password);
        user.Password = PasswordHasher.HashPassword(updateView.NewPassword);
        await userManager.UpdateUser(user);
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(26, 3);
        interpolatedStringHandler.AppendLiteral("ChangePassword - User ");
        interpolatedStringHandler.AppendFormatted(user.Name);
        interpolatedStringHandler.AppendLiteral(", ");
        interpolatedStringHandler.AppendFormatted(user.Id);
        interpolatedStringHandler.AppendLiteral(", ");
        interpolatedStringHandler.AppendFormatted(user.Email);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogInformation(stringAndClear, objArray);
        return (IActionResult) new OkObjectResult((object) true);
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(28, 1);
        interpolatedStringHandler.AppendLiteral("Exception - ChangePassword: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "ChangePassword error");
      }
    }

    [FunctionName("ResetPassword")]
    [OpenApiOperation("reset-password", new string[] {"reset-password"})]
    [OpenApiRequestBody("application/json", typeof (ResetPasswordViewModel), Description = "Email", Required = true)]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> ResetPassword(
      [HttpTrigger] HttpRequest req,
      ILogger log,
      [Microsoft.Azure.WebJobs.SendGrid(ApiKey = "SendGridApiKey")] IAsyncCollector<SendGridMessage> messageCollector)
    {
      try
      {
        HttpResponseBody<ResetPasswordViewModel> bodyAsync = await req.GetBodyAsync<ResetPasswordViewModel>();
        if (!bodyAsync.IsValid)
          return (IActionResult) new BadRequestObjectResult((object) ("Model is invalid: " + string.Join(", ", bodyAsync.ValidationResults.Select<ValidationResult, string>((Func<ValidationResult, string>) (s => s.ErrorMessage)).ToArray<string>())));
        ResetPasswordViewModel updateView = bodyAsync.Value;
        UsersManager userManager = new UsersManager();
        User user = await userManager.GetUserByName(updateView.Username);
        if (user == null)
          return (IActionResult) new NotFoundObjectResult((object) updateView.Username);
        string password = PasswordHasher.GeneratePassword();
        user.Password = PasswordHasher.HashPassword(password);
        SendGridMessage sendGridMessage = new SendGridMessage()
        {
          From = new EmailAddress("kalin252@gmail.com", "Artberry"),
          Subject = "Artberry - Reset Password",
          HtmlContent = user.Name + " your password has been reset. Use the current password to login: " + password + " </br> You can change your password in the user settings page"
        };
        sendGridMessage.AddTo(new EmailAddress(user.Email, user.Name));
        await messageCollector.AddAsync(sendGridMessage, new CancellationToken());
        await messageCollector.FlushAsync(new CancellationToken());
        await userManager.UpdateUser(user);
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 3);
        interpolatedStringHandler.AppendLiteral("ResetPassword - User ");
        interpolatedStringHandler.AppendFormatted(user.Name);
        interpolatedStringHandler.AppendLiteral(", ");
        interpolatedStringHandler.AppendFormatted(user.Id);
        interpolatedStringHandler.AppendLiteral(", ");
        interpolatedStringHandler.AppendFormatted(user.Email);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogInformation(stringAndClear, objArray);
        return (IActionResult) new OkObjectResult((object) true);
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(27, 1);
        interpolatedStringHandler.AppendLiteral("Exception - ResetPassword: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "ResetPassword error");
      }
    }

    [FunctionName("ClearLogs")]
    public static async Task ClearLogs(
      [TimerTrigger("0 00 08 * * *")] TimerInfo myTimer,
      ILogger log,
      [Microsoft.Azure.WebJobs.SendGrid(ApiKey = "SendGridApiKey")] IAsyncCollector<SendGridMessage> messageCollector)
    {
      await new EventLogManager().ClearEventLogs();
    }

    [FunctionName("AddListenLog")]
    [OpenApiOperation("add-listenlog/{id}", new string[] {"add-log"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiParameter("id", In = ParameterLocation.Query, Required = true, Type = typeof (string), Description = "My user id")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (UserViewModel), Description = "User info")]
    public static async Task<IActionResult> AddListenLog([HttpTrigger] HttpRequest req, ILogger log, string id)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        if (string.IsNullOrEmpty(sessionId))
          return (IActionResult) new UnauthorizedResult();
        string str1 = await new SessionManager().ValidateSessionReturnUserId(sessionId);
        if (string.IsNullOrEmpty(str1))
          return (IActionResult) new BadRequestResult();
        string str2 = Guid.NewGuid().ToString();
        EventLog eventLog = new EventLog();
        eventLog.UserId = str1;
        eventLog.Description = id == "1" ? "Listen Red" : "Listen White";
        eventLog.EventId = id == "1" ? 3 : 4;
        eventLog.PartitionKey = str2;
        eventLog.RowKey = str2;
        await new EventLogManager().AddEventLog(eventLog);
        return (IActionResult) new OkResult();
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 1);
        interpolatedStringHandler.AppendLiteral("Exception - GetUserInfo: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "GetUserInfo error");
      }
    }
  }
}
