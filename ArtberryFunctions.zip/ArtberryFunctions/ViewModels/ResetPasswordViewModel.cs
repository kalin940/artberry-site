﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.ViewModels.ResetPasswordViewModel
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using System.ComponentModel.DataAnnotations;

namespace ArtberryFunctions.ViewModels
{
  public class ResetPasswordViewModel
  {
    [Required(ErrorMessage = "The Username is required")]
    public string Username { get; set; }
  }
}
