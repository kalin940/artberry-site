﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: Extension]
[assembly: AssemblyCompany("ArtberryFunctions")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("ArtberryFunctions")]
[assembly: AssemblyTitle("ArtberryFunctions")]
[assembly: AssemblyVersion("1.0.0.0")]
