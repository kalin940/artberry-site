﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.AdminFunctions
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.Helpers;
using ArtberryFunctions.Managers;
using ArtberryFunctions.StorageEntities;
using ArtberryFunctions.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace ArtberryFunctions
{
  public static class AdminFunctions
  {
    [FunctionName("Register")]
    [OpenApiOperation("register", new string[] {"register"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiRequestBody("application/json", typeof (RegisterViewModel), Description = "User credentials", Required = true)]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> Register(
      [HttpTrigger] HttpRequest req,
      [Table("Users", Connection = "AzureWebJobsStorage")] IAsyncCollector<User> todoTableCollector,
      ILogger log,
      [Microsoft.Azure.WebJobs.SendGrid(ApiKey = "SendGridApiKey")] IAsyncCollector<SendGridMessage> messageCollector)
    {
      log.LogInformation("C# HTTP trigger function processed a request.");
      try
      {
        HttpResponseBody<RegisterViewModel> bodyAsync = await req.GetBodyAsync<RegisterViewModel>();
        if (!bodyAsync.IsValid)
          return (IActionResult) new BadRequestObjectResult((object) ("Model is invalid: " + string.Join(", ", bodyAsync.ValidationResults.Select<ValidationResult, string>((Func<ValidationResult, string>) (s => s.ErrorMessage)).ToArray<string>())));
        RegisterViewModel registerModel = bodyAsync.Value;
        string sessionId = req.Headers["SessionId"].ToString();
        if (string.IsNullOrEmpty(sessionId))
          return (IActionResult) new UnauthorizedResult();
        if (!await new SessionManager().IsAdminSession(sessionId))
          return (IActionResult) new UnauthorizedResult();
        User user = new User();
        user.PartitionKey = Guid.NewGuid().ToString();
        user.RowKey = Guid.NewGuid().ToString();
        user.Email = registerModel.Email;
        user.Name = registerModel.Name;
        user.IsAdmin = registerModel.IsAdmin;
        user.IsSubscriptionEnabled = registerModel.IsSubscriptionEnabled;
        user.SubscriptionId = registerModel.SubscriptionId;
        user.SubscriptionStart = new DateTime?(DateTime.UtcNow);
        user.SubscriptionEnd = new DateTime?(DateTime.UtcNow.AddMonths(6));
        user.Password = PasswordHasher.HashPassword(registerModel.Password);
        await todoTableCollector.AddAsync(user, new CancellationToken());
        SendGridMessage sendGridMessage = new SendGridMessage()
        {
          From = new EmailAddress("kalin252@gmail.com", "Artberry"),
          Subject = "Welcome to artberry",
          HtmlContent = "Your account has been created. Visit our website and login using your email and password. Your current password is: " + registerModel.Password + " <br/> <a href='https://ashy-pebble-0a5a86103.2.azurestaticapps.net'>Visit us</a>"
        };
        sendGridMessage.AddTo(new EmailAddress(registerModel.Email, registerModel.Name));
        await messageCollector.AddAsync(sendGridMessage, new CancellationToken());
        await messageCollector.FlushAsync(new CancellationToken());
        registerModel = (RegisterViewModel) null;
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(29, 2);
        interpolatedStringHandler.AppendLiteral("Error thrown at ");
        interpolatedStringHandler.AppendFormatted<DateTime>(DateTime.Now);
        interpolatedStringHandler.AppendLiteral(". Exception: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) false);
      }
      return (IActionResult) new OkObjectResult((object) true);
    }

    [FunctionName("EditUser")]
    [OpenApiOperation("edit-user", new string[] {"edit-user"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiRequestBody("application/json", typeof (UpdateUserViewModel), Description = "User info", Required = true)]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> EditUser([HttpTrigger] HttpRequest req, ILogger log)
    {
      string sessionId = req.Headers["SessionId"].ToString();
      if (string.IsNullOrEmpty(sessionId))
        return (IActionResult) new UnauthorizedResult();
      if (!await new SessionManager().IsAdminSession(sessionId))
        return (IActionResult) new UnauthorizedResult();
      HttpResponseBody<UpdateUserViewModel> bodyAsync = await req.GetBodyAsync<UpdateUserViewModel>();
      if (!bodyAsync.IsValid)
        return (IActionResult) new BadRequestObjectResult((object) ("Model is invalid: " + string.Join(", ", bodyAsync.ValidationResults.Select<ValidationResult, string>((Func<ValidationResult, string>) (s => s.ErrorMessage)).ToArray<string>())));
      UpdateUserViewModel updateView = bodyAsync.Value;
      UsersManager userManager = new UsersManager();
      User user = await userManager.GetUser(updateView.Id);
      if (user == null)
        return (IActionResult) new NotFoundObjectResult((object) updateView.Id);
      user.Name = updateView.Name;
      user.Email = updateView.Email;
      user.IsSubscriptionEnabled = updateView.IsSubscriptionEnabled;
      user.SubscriptionId = updateView.SubscriptionId;
      user.SubscriptionStart = updateView.SubscriptionStart;
      user.SubscriptionEnd = updateView.SubscriptionEnd;
      await userManager.UpdateUser(user);
      return (IActionResult) new OkObjectResult((object) true);
    }

    [FunctionName("DeleteUser")]
    [OpenApiOperation("edit-user", new string[] {"delete-user"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiRequestBody("application/json", typeof (UpdateUserViewModel), Description = "User info", Required = true)]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> DeleteUser([HttpTrigger] HttpRequest req, ILogger log)
    {
      string sessionId = req.Headers["SessionId"].ToString();
      if (string.IsNullOrEmpty(sessionId))
        return (IActionResult) new UnauthorizedResult();
      SessionManager sessionManager = new SessionManager();
      if (!await sessionManager.IsAdminSession(sessionId))
        return (IActionResult) new UnauthorizedResult();
      HttpResponseBody<DeleteUserViewModel> bodyAsync = await req.GetBodyAsync<DeleteUserViewModel>();
      if (!bodyAsync.IsValid)
        return (IActionResult) new BadRequestObjectResult((object) ("Model is invalid: " + string.Join(", ", bodyAsync.ValidationResults.Select<ValidationResult, string>((Func<ValidationResult, string>) (s => s.ErrorMessage)).ToArray<string>())));
      DeleteUserViewModel updateView = bodyAsync.Value;
      UsersManager userManager = new UsersManager();
      User user = await userManager.GetUser(updateView.Id);
      if (user == null)
        return (IActionResult) new NotFoundObjectResult((object) updateView.Id);
      await userManager.DeleteUser(user);
      foreach (Session userSession in await sessionManager.GetUserSessions(updateView.Id))
      {
        int num = await sessionManager.DeleteSession(userSession.Id) ? 1 : 0;
      }
      return (IActionResult) new OkObjectResult((object) true);
    }

    [FunctionName("GetUsers")]
    [OpenApiOperation("get-users", new string[] {"get-users"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (IEnumerable<User>), Description = "Users list")]
    public static async Task<IActionResult> GetUsers([HttpTrigger] HttpRequest req, ILogger log)
    {
      log.LogInformation("C# HTTP trigger function processed a request.");
      string sessionId = req.Headers["SessionId"].ToString();
      if (string.IsNullOrEmpty(sessionId))
        return (IActionResult) new UnauthorizedResult();
      return !await new SessionManager().IsAdminSession(sessionId) ? (IActionResult) new UnauthorizedResult() : (IActionResult) new OkObjectResult((object) await new UsersManager().GetUsers());
    }

    [FunctionName("GetUser")]
    [OpenApiOperation("get-user", new string[] {"get-user"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiParameter("id", In = ParameterLocation.Query, Required = true, Type = typeof (string), Description = "User id")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (User), Description = "User info")]
    public static async Task<IActionResult> GetUser([HttpTrigger] HttpRequest req, ILogger log, string id)
    {
      log.LogInformation("C# HTTP trigger function processed a request.");
      string sessionId = req.Headers["SessionId"].ToString();
      if (string.IsNullOrEmpty(sessionId))
        return (IActionResult) new UnauthorizedResult();
      if (!await new SessionManager().IsAdminSession(sessionId))
        return (IActionResult) new UnauthorizedResult();
      User user = await new UsersManager().GetUser(id);
      return user != null ? (IActionResult) new OkObjectResult((object) user) : (IActionResult) new NotFoundObjectResult((object) id);
    }

    [FunctionName("GetUserLogs")]
    [OpenApiOperation("get-logs/{id}", new string[] {"user-info"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login")]
    [OpenApiParameter("id", In = ParameterLocation.Query, Required = true, Type = typeof (string), Description = "My user id")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (UserViewModel), Description = "User info")]
    public static async Task<IActionResult> AddListenLog([HttpTrigger] HttpRequest req, ILogger log, string id)
    {
      try
      {
        return string.IsNullOrEmpty(req.Headers["SessionId"].ToString()) ? (IActionResult) new UnauthorizedResult() : (IActionResult) new OkObjectResult((object) (await new EventLogManager().GetEvents(id)).OrderByDescending<EventLog, DateTimeOffset>((Func<EventLog, DateTimeOffset>) (p => p.Timestamp)).GroupBy<EventLog, int>((Func<EventLog, int>) (p => p.EventId)).Select<IGrouping<int, EventLog>, EventLog>((Func<IGrouping<int, EventLog>, EventLog>) (g => g.FirstOrDefault<EventLog>())).ToList<EventLog>());
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 1);
        interpolatedStringHandler.AppendLiteral("Exception - GetUserInfo: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "GetUserInfo error");
      }
    }
  }
}
