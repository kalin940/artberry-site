﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.Helpers.PasswordHasher
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace ArtberryFunctions.Helpers
{
  public class PasswordHasher
  {
    public static string HashPassword(string password)
    {
      if (password == null)
        throw new ArgumentNullException(nameof (password));
      byte[] salt;
      byte[] bytes;
      using (Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, 16, 1000))
      {
        salt = rfc2898DeriveBytes.Salt;
        bytes = rfc2898DeriveBytes.GetBytes(32);
      }
      byte[] numArray = new byte[49];
      Buffer.BlockCopy((Array) salt, 0, (Array) numArray, 1, 16);
      Buffer.BlockCopy((Array) bytes, 0, (Array) numArray, 17, 32);
      return Convert.ToBase64String(numArray);
    }

    public static string GeneratePassword(int length = 8)
    {
      Random random = new Random();
      byte[] data = new byte[length];
      new RNGCryptoServiceProvider().GetBytes(data);
      StringBuilder stringBuilder = new StringBuilder();
      foreach (byte num in data)
      {
        switch (random.Next(4))
        {
          case 0:
            stringBuilder.Append("abcdefghijklmnopqrstuvwxyz"[(int) num % "abcdefghijklmnopqrstuvwxyz".Count<char>()]);
            break;
          case 1:
            stringBuilder.Append("ABCDEFGHIJKLMNOPQRSTUVWXYZ"[(int) num % "ABCDEFGHIJKLMNOPQRSTUVWXYZ".Count<char>()]);
            break;
          case 2:
            stringBuilder.Append("1234567890"[(int) num % "1234567890".Count<char>()]);
            break;
          case 3:
            stringBuilder.Append("!@#$%^&*_-=+"[(int) num % "!@#$%^&*_-=+".Count<char>()]);
            break;
        }
      }
      return stringBuilder.ToString();
    }

    public static bool VerifyHashedPassword(string hashedPassword, string password)
    {
      if (hashedPassword == null)
        return false;
      if (password == null)
        throw new ArgumentNullException(nameof (password));
      byte[] src = Convert.FromBase64String(hashedPassword);
      if (src.Length != 49 || src[0] != (byte) 0)
        return false;
      byte[] numArray1 = new byte[16];
      Buffer.BlockCopy((Array) src, 1, (Array) numArray1, 0, 16);
      byte[] numArray2 = new byte[32];
      Buffer.BlockCopy((Array) src, 17, (Array) numArray2, 0, 32);
      byte[] bytes;
      using (Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, numArray1, 1000))
        bytes = rfc2898DeriveBytes.GetBytes(32);
      return PasswordHasher.AreHashesEqual(numArray2, bytes);
    }

    private static bool AreHashesEqual(byte[] firstHash, byte[] secondHash)
    {
      int num1 = firstHash.Length <= secondHash.Length ? firstHash.Length : secondHash.Length;
      int num2 = firstHash.Length ^ secondHash.Length;
      for (int index = 0; index < num1; ++index)
        num2 |= (int) firstHash[index] ^ (int) secondHash[index];
      return num2 == 0;
    }
  }
}
