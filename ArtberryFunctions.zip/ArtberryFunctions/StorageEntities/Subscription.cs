﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.StorageEntities.Subscription
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using Microsoft.WindowsAzure.Storage.Table;

namespace ArtberryFunctions.StorageEntities
{
  public class Subscription : TableEntity
  {
    public int Id { get; set; }

    public string Name { get; set; }

    public int SessionsNumber { get; set; }

    public double Price { get; set; }

    public int MonthsDuration { get; set; }

    public string Description { get; set; }
  }
}
