﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.SubscriptionFunctions
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.Managers;
using ArtberryFunctions.StorageEntities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace ArtberryFunctions
{
  public class SubscriptionFunctions
  {
    [FunctionName("GetSubscriptions")]
    [OpenApiOperation("get-subscriptions", new string[] {"subscriptions"})]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (IEnumerable<Subscription>), Description = "Subscription list with info")]
    public static async Task<IActionResult> GetSubscriptions([HttpTrigger] HttpRequest req, ILogger log)
    {
      try
      {
        return (IActionResult) new OkObjectResult((object) await new SubscriptionManager().GetSubscriptions());
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(30, 1);
        interpolatedStringHandler.AppendLiteral("Exception - GetSubscriptions: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "GetSubscriptions error");
      }
    }

    [FunctionName("ExpiringSubscriptions")]
    public static async Task ExpiringSubscriptions(
      [TimerTrigger("0 00 08 * * *")] TimerInfo myTimer,
      ILogger log,
      [Microsoft.Azure.WebJobs.SendGrid(ApiKey = "SendGridApiKey")] IAsyncCollector<SendGridMessage> messageCollector)
    {
      foreach (User user in await new UsersManager().GetUsers())
      {
        if (user.IsSubscriptionEnabled && user.SubscriptionEnd.HasValue)
        {
          DateTime dateTime = DateTime.Now;
          dateTime = dateTime.AddDays(10.0);
          DateTime date1 = dateTime.Date;
          dateTime = user.SubscriptionEnd.Value;
          DateTime date2 = dateTime.Date;
          if (date1 == date2)
          {
            SendGridMessage sendGridMessage = new SendGridMessage()
            {
              From = new EmailAddress("kalin252@gmail.com", "Artberry"),
              Subject = "Artberry subscripion expires soon",
              HtmlContent = "Your subscription will expire in 10 days. Contact us to renew it."
            };
            sendGridMessage.AddTo(new EmailAddress(user.Email, user.Name));
            await messageCollector.AddAsync(sendGridMessage, new CancellationToken());
            await messageCollector.FlushAsync(new CancellationToken());
          }
        }
      }
    }
  }
}
