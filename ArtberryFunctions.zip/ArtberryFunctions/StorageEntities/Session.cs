﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.StorageEntities.Session
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using Microsoft.WindowsAzure.Storage.Table;
using System;

namespace ArtberryFunctions.StorageEntities
{
  public class Session : TableEntity
  {
    public string Id { get; set; } = Guid.NewGuid().ToString();

    public string UserId { get; set; }

    public DateTime DateCreated { get; set; } = DateTime.UtcNow;

    public DateTime DateEnd { get; set; }

    public int ApplicationTypeId { get; set; }

    public bool IsAdmin { get; set; }
  }
}
