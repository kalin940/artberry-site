﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.Managers.SubscriptionManager
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.StorageEntities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ArtberryFunctions.Managers
{
  public class SubscriptionManager
  {
    public CloudTable SubscriptionsTable { get; set; }

    public SubscriptionManager() => this.SubscriptionsTable = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureWebJobsStorage")).CreateCloudTableClient().GetTableReference("Subscriptions");

    public SubscriptionManager(CloudTable table) => this.SubscriptionsTable = table;

    public async Task<Subscription> GetSubscription(int subId)
    {
      TableQuerySegment<Subscription> source = await this.SubscriptionsTable.ExecuteQuerySegmentedAsync<Subscription>(new TableQuery<Subscription>().Where(TableQuery.GenerateFilterConditionForInt("Id", "eq", subId)), new TableContinuationToken());
      return source != null ? source.FirstOrDefault<Subscription>() : (Subscription) null;
    }

    public async Task<IEnumerable<Subscription>> GetSubscriptions()
    {
      TableQuerySegment<Subscription> source = await this.SubscriptionsTable.ExecuteQuerySegmentedAsync<Subscription>(new TableQuery<Subscription>(), new TableContinuationToken());
      return (source != null ? (IEnumerable<Subscription>) source.ToArray<Subscription>() : (IEnumerable<Subscription>) (Subscription[]) null) ?? Enumerable.Empty<Subscription>();
    }
  }
}
