﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.ViewModels.UpdateUserEmailViewModel
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using System.ComponentModel.DataAnnotations;

namespace ArtberryFunctions.ViewModels
{
  public class UpdateUserEmailViewModel
  {
    [Required(ErrorMessage = "The Id is required")]
    public string Id { get; set; }

    [Required(ErrorMessage = "The Email address is required")]
    [EmailAddress(ErrorMessage = "Invalid Email address")]
    public string Email { get; set; }
  }
}
