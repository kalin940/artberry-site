﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.SessionFunctions
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.Helpers;
using ArtberryFunctions.Managers;
using ArtberryFunctions.StorageEntities;
using ArtberryFunctions.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace ArtberryFunctions
{
  public static class SessionFunctions
  {
    [FunctionName("GetSession")]
    [OpenApiOperation("get-session", new string[] {"login"})]
    [OpenApiRequestBody("application/json", typeof (LoginViewModel), Description = "Username, password and applicationType. applicationType: 0 - Website, 1 - Mobile, 2 - Desktop", Required = true)]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (Session), Description = "The OK response")]
    public static async Task<IActionResult> GetSession(
      [HttpTrigger] HttpRequest req,
      [Table("Sessions", Connection = "AzureWebJobsStorage")] IAsyncCollector<Session> sessionsCollector,
      ILogger log)
    {
      try
      {
        HttpResponseBody<LoginViewModel> bodyAsync = await req.GetBodyAsync<LoginViewModel>();
        if (!bodyAsync.IsValid)
          return (IActionResult) new BadRequestObjectResult((object) ("Model is invalid: " + string.Join(", ", bodyAsync.ValidationResults.Select<ValidationResult, string>((Func<ValidationResult, string>) (s => s.ErrorMessage)).ToArray<string>())));
        LoginViewModel loginModel = bodyAsync.Value;
        User dbUser = await new UsersManager().ValidateUser(loginModel);
        if (dbUser == null)
          return (IActionResult) new UnauthorizedResult();
        if (!dbUser.SubscriptionId.HasValue)
          return (IActionResult) new BadRequestObjectResult((object) "No subscription");
        if (!dbUser.IsSubscriptionEnabled)
          return (IActionResult) new BadRequestObjectResult((object) "Expired subscription");
        SessionManager sessionManager = new SessionManager();
        IEnumerable<Session> sessions = await sessionManager.GetUserSessions(dbUser.Id);
        Subscription subscription = await new SubscriptionManager().GetSubscription(dbUser.SubscriptionId.Value);
        if (subscription == null)
          return (IActionResult) new BadRequestObjectResult((object) "User has no subscription");
        List<Session> list = sessions.Where<Session>((Func<Session, bool>) (p => p.DateEnd >= DateTime.UtcNow)).ToList<Session>();
        if (subscription.SessionsNumber <= list.Count<Session>())
        {
          int num = await sessionManager.DeleteSession(list.OrderBy<Session, DateTime>((Func<Session, DateTime>) (p => p.DateCreated)).First<Session>().Id) ? 1 : 0;
        }
        string id = Guid.NewGuid().ToString();
        Session session = new Session();
        session.ApplicationTypeId = loginModel.ApplicationType;
        session.DateCreated = DateTime.UtcNow;
        session.DateEnd = DateTime.UtcNow.AddDays(10.0);
        session.PartitionKey = id;
        session.RowKey = id;
        session.Id = id;
        session.UserId = dbUser.Id;
        session.IsAdmin = dbUser.IsAdmin;
        Session newSession = session;
        await sessionsCollector.AddAsync(newSession, new CancellationToken());
        EventLog eventLog = new EventLog();
        eventLog.UserId = dbUser.Id;
        eventLog.Description = "Login";
        eventLog.EventId = 1;
        eventLog.PartitionKey = id;
        eventLog.RowKey = id;
        await new EventLogManager().AddEventLog(eventLog);
        return (IActionResult) new OkObjectResult((object) newSession);
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(24, 1);
        interpolatedStringHandler.AppendLiteral("Exception - GetSession: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "GetSession error");
      }
    }

    [FunctionName("CheckSession")]
    [OpenApiOperation("check-session", new string[] {"check-session"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login. Put it in each request as a request header")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> CheckSession([HttpTrigger] HttpRequest req, ILogger log)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        return string.IsNullOrEmpty(sessionId) ? (IActionResult) new UnauthorizedResult() : (IActionResult) new OkObjectResult((object) await new SessionManager().ValidateSession(sessionId));
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(26, 1);
        interpolatedStringHandler.AppendLiteral("Exception - CheckSession: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "CheckSession error");
      }
    }

    [FunctionName("CheckAdminSession")]
    [OpenApiOperation("check-session", new string[] {"check-adminsession"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login. Put it in each request as a request header")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> CheckAdminSession([HttpTrigger] HttpRequest req, ILogger log)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        return string.IsNullOrEmpty(sessionId) ? (IActionResult) new UnauthorizedResult() : (IActionResult) new OkObjectResult((object) await new SessionManager().IsAdminSession(sessionId));
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(26, 1);
        interpolatedStringHandler.AppendLiteral("Exception - CheckSession: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "CheckSession error");
      }
    }

    [FunctionName("Logout")]
    [OpenApiOperation("logout", new string[] {"logout"})]
    [OpenApiParameter("SessionId", In = ParameterLocation.Header, Required = true, Type = typeof (string), Description = "The user receives a SessionId on login. Put it in each request as a request header")]
    [OpenApiResponseWithBody(HttpStatusCode.OK, "application/json", typeof (bool), Description = "Receive true or false")]
    public static async Task<IActionResult> Logout([HttpTrigger] HttpRequest req, ILogger log)
    {
      try
      {
        string sessionId = req.Headers["SessionId"].ToString();
        if (string.IsNullOrEmpty(sessionId))
          return (IActionResult) new UnauthorizedResult();
        log.LogInformation("Logout for session " + sessionId);
        return (IActionResult) new OkObjectResult((object) await new SessionManager().DeleteSession(sessionId));
      }
      catch (Exception ex)
      {
        ILogger logger = log;
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(20, 1);
        interpolatedStringHandler.AppendLiteral("Exception - Logout: ");
        interpolatedStringHandler.AppendFormatted<Exception>(ex);
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        object[] objArray = Array.Empty<object>();
        logger.LogError(stringAndClear, objArray);
        return (IActionResult) new BadRequestObjectResult((object) "Logout error");
      }
    }
  }
}
