﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.Helpers.HttpRequestExtensions
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace ArtberryFunctions.Helpers
{
  public static class HttpRequestExtensions
  {
    public static async Task<HttpResponseBody<T>> GetBodyAsync<T>(this HttpRequest request)
    {
      HttpResponseBody<T> body = new HttpResponseBody<T>();
      body.Value = JsonConvert.DeserializeObject<T>(await HttpRequestExtensions.ReadAsStringAsync(request));
      List<ValidationResult> validationResultList = new List<ValidationResult>();
      body.IsValid = Validator.TryValidateObject((object) body.Value, new ValidationContext((object) body.Value, (IServiceProvider) null, (IDictionary<object, object>) null), (ICollection<ValidationResult>) validationResultList, true);
      body.ValidationResults = (IEnumerable<ValidationResult>) validationResultList;
      HttpResponseBody<T> bodyAsync = body;
      body = (HttpResponseBody<T>) null;
      return bodyAsync;
    }
  }
}
