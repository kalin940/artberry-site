﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.StorageEntities.ApplicationTypes
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

namespace ArtberryFunctions.StorageEntities
{
  public enum ApplicationTypes
  {
    Website,
    Mobile,
    Desktop,
  }
}
