﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.Managers.UsersManager
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using ArtberryFunctions.Helpers;
using ArtberryFunctions.StorageEntities;
using ArtberryFunctions.ViewModels;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ArtberryFunctions.Managers
{
  public class UsersManager
  {
    public CloudTable UsersTable { get; set; }

    public UsersManager() => this.UsersTable = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureWebJobsStorage")).CreateCloudTableClient().GetTableReference("Users");

    public UsersManager(CloudTable table) => this.UsersTable = table;

    public async Task<User> ValidateUser(LoginViewModel userData)
    {
      TableQuerySegment<User> source = await this.UsersTable.ExecuteQuerySegmentedAsync<User>(new TableQuery<User>().Where(TableQuery.GenerateFilterCondition("Name", "eq", userData.Username)), new TableContinuationToken());
      if ((source != null ? source.FirstOrDefault<User>() : (User) null) == null)
        return (User) null;
      User user = source.FirstOrDefault<User>();
      return !PasswordHasher.VerifyHashedPassword(user.Password, userData.Password) ? (User) null : user;
    }

    public async Task<User> GetUser(string id)
    {
      TableQuerySegment<User> source = await this.UsersTable.ExecuteQuerySegmentedAsync<User>(new TableQuery<User>().Where(TableQuery.GenerateFilterCondition("Id", "eq", id)), new TableContinuationToken());
      return source != null ? source.FirstOrDefault<User>() : (User) null;
    }

    public async Task<IEnumerable<User>> GetUsers()
    {
      TableQuerySegment<User> source = await this.UsersTable.ExecuteQuerySegmentedAsync<User>(new TableQuery<User>(), new TableContinuationToken());
      return (source != null ? (IEnumerable<User>) source.ToArray<User>() : (IEnumerable<User>) (User[]) null) ?? Enumerable.Empty<User>();
    }

    public async Task<User> GetUserByEmail(string email)
    {
      TableQuerySegment<User> source = await this.UsersTable.ExecuteQuerySegmentedAsync<User>(new TableQuery<User>().Where(TableQuery.GenerateFilterCondition("Email", "eq", email)), new TableContinuationToken());
      return source != null ? source.FirstOrDefault<User>() : (User) null;
    }

    public async Task<User> GetUserByName(string name)
    {
      TableQuerySegment<User> source = await this.UsersTable.ExecuteQuerySegmentedAsync<User>(new TableQuery<User>().Where(TableQuery.GenerateFilterCondition("Name", "eq", name)), new TableContinuationToken());
      return source != null ? source.FirstOrDefault<User>() : (User) null;
    }

    public async Task UpdateUser(User user)
    {
      TableResult tableResult = await this.UsersTable.ExecuteAsync(TableOperation.Replace((ITableEntity) user));
    }

    public async Task DeleteUser(User user)
    {
      TableResult tableResult = await this.UsersTable.ExecuteAsync(TableOperation.Delete((ITableEntity) user));
    }
  }
}
