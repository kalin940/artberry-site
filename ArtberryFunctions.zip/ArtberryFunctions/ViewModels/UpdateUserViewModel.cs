﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.ViewModels.UpdateUserViewModel
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using System;
using System.ComponentModel.DataAnnotations;

namespace ArtberryFunctions.ViewModels
{
  public class UpdateUserViewModel
  {
    [Required(ErrorMessage = "The Id is required")]
    public string Id { get; set; }

    public string Email { get; set; }

    public string Name { get; set; }

    public bool IsSubscriptionEnabled { get; set; }

    public int? SubscriptionId { get; set; }

    public DateTime? SubscriptionEnd { get; set; }

    public DateTime? SubscriptionStart { get; set; }
  }
}
