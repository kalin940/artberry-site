﻿// Decompiled with JetBrains decompiler
// Type: ArtberryFunctions.ViewModels.RegisterViewModel
// Assembly: ArtberryFunctions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 53F310EE-68D7-4D6D-841E-7AF1F99B869C
// Assembly location: C:\Users\kalin\Downloads\wwwroot\bin\ArtberryFunctions.dll

using System.ComponentModel.DataAnnotations;

namespace ArtberryFunctions.ViewModels
{
  public class RegisterViewModel
  {
    [Required(ErrorMessage = "The Name is required")]
    public string Name { get; set; }

    [Required(ErrorMessage = "The Email address is required")]
    [EmailAddress(ErrorMessage = "Invalid Email address")]
    public string Email { get; set; }

    [Required(ErrorMessage = "The Password is required")]
    [DataType(DataType.Password)]
    [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
    [RegularExpression("^((?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])|(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[^a-zA-Z0-9])|(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[^a-zA-Z0-9])|(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^a-zA-Z0-9])).{6,}$", ErrorMessage = "Passwords must be at least 6 characters and contain at 3 of 4 of the following: upper case (A-Z), lower case (a-z), number (0-9) and special character (e.g. !@#$%^&*)")]
    public string Password { get; set; }

    public bool IsAdmin { get; set; }

    public bool IsSubscriptionEnabled { get; set; }

    public int? SubscriptionId { get; set; }
  }
}
